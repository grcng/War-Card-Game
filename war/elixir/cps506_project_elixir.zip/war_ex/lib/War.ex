defmodule War do
  @moduledoc """
    Documentation for `War`.
  """

  @doc """
    Function stub for deal/1 is given below. Feel free to add 
    as many additional helper functions as you want. 

    The tests for the deal function can be found in test/war_test.exs. 
    You can add your five test cases to this file.

    Run the tester by executing 'mix test' from the war directory 
    (the one containing mix.exs)
  """

  def deal(shuf) do
    :error
  end

end
