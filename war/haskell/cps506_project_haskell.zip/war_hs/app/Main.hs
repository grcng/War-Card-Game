module Main where

main :: IO ()
main = WarTest.main
